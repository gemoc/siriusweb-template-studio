package com.example.siriusweb_template_studio.template_studio_app;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TemplateStudioAppApplication {

	public static void main(String[] args) {
		SpringApplication.run(TemplateStudioAppApplication.class, args);
	}

}
